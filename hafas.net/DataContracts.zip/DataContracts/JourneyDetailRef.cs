﻿using System.Runtime.Serialization;

namespace hafas.net
{
    [DataContract(Name = "JourneyDetailRef")]
    public class JourneyDetailRef
    {
        public string ReferenceUrl { get; set; }
    }
}
