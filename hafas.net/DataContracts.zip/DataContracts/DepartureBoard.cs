﻿using System.Runtime.Serialization;

namespace hafas.net
{
    /// <summary>
    /// The departure board lists up to 20 departures at a specific stop/station or group of stop/stations.
    /// </summary>
    [DataContract(Name = "departureboard")]
    public class DepartureBoard
    {
        [DataMember(Name = "departure")]
        public Departure[] Departures { get; set; }

        /// <summary>
        /// If some problem occurs while creating the departure board you can find an error code here. 
        /// Note: These error codes are not suitable for end users but only for reporting purposes. 
        /// Most of the errors do not indicate a system failure but data or request parameter issues.
        /// </summary>
        public string Error { get; set; }
    }
}
