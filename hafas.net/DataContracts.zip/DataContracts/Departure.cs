﻿using System.Runtime.Serialization;

namespace hafas.net
{
    /// <summary>
    /// The element Departure contains all information about a departure like 
    /// time, date, stop/station name, track, realtime time, date and track, direction, 
    /// name and type of the journey. It also contains a reference to journey details.
    /// </summary>
    [DataContract(Name = "Departure")]
    public class Departure
    {
        /// <summary>
        /// Reference to journey details.
        /// </summary>
        public JourneyDetailRef JourneyDetailRef { get; set; }

        /// <summary>
        /// The attribute name specifies the name of the departing journey (e.g. "Bus 100").
        /// </summary>
        [DataMember(Name = "name")]
        public string Name { get; set; }

        /// <summary>
        /// The attribute type specifies the type of the departing journey. 
        /// </summary>
        [DataMember(Name = "type")]
        public string Type { get; set; }

        /// <summary>
        /// Direction information.
        /// </summary>
        [DataMember(Name = "direction")]
        public string Direction { get; set; }

        //[DataMember(Name = "stopid")]
        //public string Stopid { get; set; }

        /// <summary>
        /// Contains the name of the stop/station.
        /// </summary>
        [DataMember(Name = "stop")]
        public string Stop { get; set; }

        /// <summary>
        /// Time in format HH:MM.
        /// </summary>
        [DataMember(Name = "time")]
        public string Time { get; set; }

        /// <summary>
        /// Date in format DD.MM.YY.
        /// </summary>
        [DataMember(Name = "date")]
        public string Date { get; set; }

        /// <summary>
        /// This attribute gives the number of messages for this journey
        /// </summary>
        [DataMember(Name = "messages")]
        public int Messages { get; set; }

        [DataMember(Name = "journeyid")]
        public string Journeyid { get; set; }

        /// <summary>
        /// Track information, if available.
        /// </summary>
        [DataMember(Name = "track")]
        public string Track { get; set; }

        /// <summary>
        /// Realtime time in format HH:MM if available.
        /// </summary>
        [DataMember(Name = "rtime")]
        public string RtTime { get; set; }

        /// <summary>
        /// Realtime date in format DD.MM.YY, if available.
        /// </summary>
        [DataMember(Name = "rtdate")]
        public string RtDate { get; set; }

        /// <summary>
        /// Realtime track information, if available.
        /// </summary>
        [DataMember(Name = "rttrack")]
        public string RtTrack { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this journey is cancelled.
        /// </summary>
        [DataMember(Name = "cancelled")]
        public bool Cancelled { get; set; }


        /// <summary>
        /// This attribute gives the name of the final stop of this journey
        /// </summary>
        [DataMember(Name = "finalstop")]
        public string FinalStop { get; set; }

        /// <summary>
        /// This attribute gives the state of the current journey
        /// </summary>
        [DataMember(Name = "state")]
        public string State { get; set; }

        //public string FgColor { get; set; }

        //public string BgColor { get; set; }

        //public string Stroke { get; set; }
    }

    /// <summary>
    /// The attribute type specifies the type of the departing journey. 
    /// </summary>
    public enum DepartureType
    {

        /// InterCity
        IC,

        /// Lyntog
        LYN,

        /// Regionaltog
        REG,

        /// S-Tog
        S,

        /// other train
        TOG,

        /// Bus
        BUS,

        /// Express Buss
        EXB,

        /// Nattbus
        NB,

        /// Telebus, other form of transport
        TB,

        /// Ferry
        F,

        /// Metro
        M,
    }
}
